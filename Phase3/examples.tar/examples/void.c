void f(void)
{
}

void x;				/* 'x' has type void */
void g(void y) {}		/* 'y' has type void */
void *h();
void a[10];			/* 'a' has type void */
void *b[10];
