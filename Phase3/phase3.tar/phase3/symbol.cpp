#include "symbol.h"

Symbol::Symbol(const string &name, const Type &type): _name(name), _type(type)
{}