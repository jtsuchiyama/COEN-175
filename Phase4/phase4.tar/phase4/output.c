272
297
40
272
297
x: int
44
272
42
297
y: int *
foo: int()
41
123
272
297
c: int
59
297
40
297
44
297
int
int
int
int *
41
59
125
